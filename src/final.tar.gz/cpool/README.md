I worked on a Linux system for this assignment.
Usually, I work on my Mac, but the futex code would not compile on macOS.
If you have any similar issues, running this on Mirage (or another Linux system) might help.